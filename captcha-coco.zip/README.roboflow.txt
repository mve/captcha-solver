
CAPTCHA images - v4 76
==============================

This dataset was exported via roboflow.ai on February 23, 2022 at 10:43 AM GMT

It includes 76 images.
Letter are annotated in COCO format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


